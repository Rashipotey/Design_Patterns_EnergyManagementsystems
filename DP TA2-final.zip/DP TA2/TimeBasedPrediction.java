class TimeBasedPrediction implements EnergyPredictionStrategy {
    @Override
    public void predictEnergyUsage() {
        System.out.println("Predicting energy usage based on time patterns...");
    }
}
