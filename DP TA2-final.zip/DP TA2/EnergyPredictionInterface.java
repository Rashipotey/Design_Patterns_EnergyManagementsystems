interface EnergyPredictionStrategy {
    void predictEnergyUsage();
}

