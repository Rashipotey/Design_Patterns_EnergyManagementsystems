interface DeviceListener {
    void update(String message);
}
